document.write("   <div class=\"stui-pannel stui-pannel-bg clearfix\">");
document.write("				<div class=\"stui-pannel-box\">");
document.write("					<div class=\"col-pd\">");
document.write("						<a class=\"hidden-xs\" target=\"_blank\" href=\"\/\"> <img class=\"img-responsive\" src=\"https:\/\/r1.ykimg.com\/material\/0A03\/A1\/201907\/0712\/3000650\/1562901849452\/0D0100005D2802181831383537343853.jpg\" width=\"100%\"\/><\/a>");
document.write("						<a class=\"visible-xs\" target=\"_blank\" href=\"\/\"> <img class=\"img-responsive\" src=\"https:\/\/liangcang-material.alicdn.com\/prod\/upload\/f0c7c7baac5a41a6852ba14f6eb8f02d.jpg\"\/> <\/a>");
document.write("				<\/div>	");
document.write("				<\/div>");
document.write("			<\/div> ");
document.write("");
